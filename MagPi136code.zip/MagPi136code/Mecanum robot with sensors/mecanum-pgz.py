# Minimal version of mecanum-pgz
from gpiozero.pins.pigpio import PiGPIOFactory
from gpiozero import Device, PWMOutputDevice, Motor, DistanceSensor

WIDTH=800
HEIGHT=600

Device.pin_factory = PiGPIOFactory()

pwm_pin = 18
m_f_l = (2,3)
m_f_r = (22,23)
m_r_l = (14,15)
m_r_r = (24,25)

motors = [ 
    Motor(m_f_l[0], m_f_l[1], pwm=False),
    Motor(m_f_r[0], m_f_r[1], pwm=False),
    Motor(m_r_l[0], m_r_l[1], pwm=False),
    Motor(m_r_r[0], m_r_r[1], pwm=False)
    ]

pwm_out = PWMOutputDevice (pwm_pin)
dist_sensor = DistanceSensor(echo=6, trigger=5)

arrows = [
    Actor("arrow.png", center=(500,300)),   # Right
    Actor("arrow.png", center=(400,200)),   # Up
    Actor("arrow.png", center=(300,300)),   # Left
    Actor("arrow.png", center=(400,400))    # Down
    ]
arrows[1].angle = 90
arrows[2].angle = 180
arrows[3].angle = 270

# distance in meters - a value between 0 and 1
min_distance = 0.09

# list to convert key into motor on/off values to correspond with direction
# direction based on number keypad
direction = {
    keys.K_2 : (-1, -1, -1, -1), # Backwards
    keys.KP2 : (-1, -1, -1, -1), # Backwards
    keys.K_4 : (-1, 1, 1, -1),   # Left
    keys.KP4 : (-1, 1, 1, -1),   # Left
    keys.K_5 : (0, 0, 0, 0),     # Stop
    keys.KP5 : (0, 0, 0, 0),     # Stop
    keys.K_6 : (1, -1, -1, 1),   # Right
    keys.KP6 : (1, -1, -1, 1),   # Right
    keys.K_8 : (1, 1, 1, 1),     # Forwards
    keys.KP8 : (1, 1, 1, 1),     # Forwards
}

# Track direction
current_direction = (0, 0, 0, 0)

# speed is as a percentage (ie. 100 = top speed)
speed = 50
pwm_out.value = speed/100

def draw():
    screen.fill((192,192,192))
    for arrow in arrows:
        arrow.draw()

def update():
    global current_direction
    try:
        if (dist_sensor.distance <= min_distance):
            # Is robot going forward (or diagonal)
            if (current_direction[0] == 1 and current_direction[1] == 1):
                print ("Warning - crash imminent")
                # Force stop using stop key number (5)
                set_direction (direction[keys.K_5])
    except:
        print ("No distance sensor detected")

def on_key_down(key):
    global speed, current_direction
    # Get next key pressed      
    if (key in direction.keys()) :
        set_direction(direction[key])
                
def set_direction(direction):
    global current_direction
    current_direction = direction
    for i in range (0, 4):
        if direction[i] == -1:
            motors[i].backward()
        elif direction[i] == 1:
            motors[i].forward()
        else:
            motors[i].stop()    
                